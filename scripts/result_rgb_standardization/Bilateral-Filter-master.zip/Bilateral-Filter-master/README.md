# Bilateral-Filter
A filter that smooths images while preserving edges.

According to mathematical formulas, we implemented a filter. This code visits all pixels and change their intensity with the new, calculated values. Changing pixels one by one is a big thing so it takes some time.
